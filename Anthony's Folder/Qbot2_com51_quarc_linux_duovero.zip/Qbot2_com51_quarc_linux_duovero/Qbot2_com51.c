/*
 * Qbot2_com51.c
 *
 * Code generation for model "Qbot2_com51".
 *
 * Model version              : 1.801
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Tue Oct 20 10:46:05 2015
 *
 * Target selection: quarc_linux_duovero.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "Qbot2_com51.h"
#include "Qbot2_com51_private.h"
#include "Qbot2_com51_dt.h"

/* Block signals (auto storage) */
B_Qbot2_com51_T Qbot2_com51_B;

/* Block states (auto storage) */
DW_Qbot2_com51_T Qbot2_com51_DW;

/* Real-time model */
RT_MODEL_Qbot2_com51_T Qbot2_com51_M_;
RT_MODEL_Qbot2_com51_T *const Qbot2_com51_M = &Qbot2_com51_M_;
static void rate_monotonic_scheduler(void);
time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(Qbot2_com51_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(Qbot2_com51_M, 2);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (Qbot2_com51_M->Timing.TaskCounters.TID[2])++;
  if ((Qbot2_com51_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.1s, 0.0s] */
    Qbot2_com51_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/* Model output function for TID0 */
void Qbot2_com51_output0(void)         /* Sample time: [0.0s, 0.0s] */
{
  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function (computation_time_block): '<Root>/Computation Time' */

  /* S-Function Block: Qbot2_com51/Computation Time (computation_time_block) */
  {
    Qbot2_com51_B.ComputationTime =
      Qbot2_com51_DW.ComputationTime_ComputationTime.seconds +
      Qbot2_com51_DW.ComputationTime_ComputationTime.nanoseconds * 1e-9;
  }

  /* Sin: '<Root>/Sine Wave' */
  Qbot2_com51_B.SineWave = sin(Qbot2_com51_P.SineWave_Freq *
    Qbot2_com51_M->Timing.t[0] + Qbot2_com51_P.SineWave_Phase) *
    Qbot2_com51_P.SineWave_Amp + Qbot2_com51_P.SineWave_Bias;

  /* S-Function (stream_server_block): '<Root>/Stream Server' */

  /* S-Function Block: Qbot2_com51/Stream Server (stream_server_block) */
  {
    t_pstream_state state;
    t_error send_result;
    t_error receive_result;
    if (Qbot2_com51_P.Constant1_Value) {
      send_result = pstream_send(Qbot2_com51_DW.StreamServer_Stream,
        &Qbot2_com51_B.SineWave);
    } else {
      send_result = 0;
    }

    Qbot2_com51_B.StreamServer_o3 = (send_result > 0);
    receive_result = pstream_receive(Qbot2_com51_DW.StreamServer_Stream,
      &Qbot2_com51_B.StreamServer_o4);
    Qbot2_com51_B.StreamServer_o5 = (receive_result > 0);
    Qbot2_com51_B.StreamServer_o2 = 0;
    if (send_result < 0 && send_result != -QERR_WOULD_BLOCK) {
      Qbot2_com51_B.StreamServer_o2 = send_result;
    } else if (receive_result < 0 && receive_result != -QERR_WOULD_BLOCK) {
      Qbot2_com51_B.StreamServer_o2 = receive_result;
    }

    pstream_get_state(Qbot2_com51_DW.StreamServer_Stream, &state);
    Qbot2_com51_B.StreamServer_o1 = state;
  }

  /* S-Function (stream_client_block): '<Root>/Stream Client' */

  /* S-Function Block: Qbot2_com51/Stream Client (stream_client_block) */
  {
    t_pstream_state state;
    t_error send_result;
    t_error receive_result;
    if (Qbot2_com51_P.Constant3_Value) {
      send_result = pstream_send(Qbot2_com51_DW.StreamClient_Stream,
        &Qbot2_com51_P.Constant2_Value);
    } else {
      send_result = 0;
    }

    Qbot2_com51_B.StreamClient_o3 = (send_result > 0);
    receive_result = pstream_receive(Qbot2_com51_DW.StreamClient_Stream,
      &Qbot2_com51_B.StreamClient_o4);
    Qbot2_com51_B.StreamClient_o5 = (receive_result > 0);
    Qbot2_com51_B.StreamClient_o2 = 0;
    if (send_result < 0 && send_result != -QERR_WOULD_BLOCK) {
      Qbot2_com51_B.StreamClient_o2 = send_result;
    } else if (receive_result < 0 && receive_result != -QERR_WOULD_BLOCK) {
      Qbot2_com51_B.StreamClient_o2 = receive_result;
    }

    pstream_get_state(Qbot2_com51_DW.StreamClient_Stream, &state);
    Qbot2_com51_B.StreamClient_o1 = state;
  }
}

/* Model update function for TID0 */
void Qbot2_com51_update0(void)         /* Sample time: [0.0s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Qbot2_com51_M->Timing.clockTick0)) {
    ++Qbot2_com51_M->Timing.clockTickH0;
  }

  Qbot2_com51_M->Timing.t[0] = Qbot2_com51_M->Timing.clockTick0 *
    Qbot2_com51_M->Timing.stepSize0 + Qbot2_com51_M->Timing.clockTickH0 *
    Qbot2_com51_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Qbot2_com51_M->Timing.clockTick1)) {
    ++Qbot2_com51_M->Timing.clockTickH1;
  }

  Qbot2_com51_M->Timing.t[1] = Qbot2_com51_M->Timing.clockTick1 *
    Qbot2_com51_M->Timing.stepSize1 + Qbot2_com51_M->Timing.clockTickH1 *
    Qbot2_com51_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
void Qbot2_com51_output2(void)         /* Sample time: [0.1s, 0.0s] */
{
  /* S-Function (kinect_initialize_block): '<Root>/Kinect Initialize' */

  /* S-Function Block: Qbot2_com51/Kinect Initialize (kinect_initialize_block) */
  {
    Qbot2_com51_B.KinectInitialize = kinect_get_status
      (Qbot2_com51_DW.KinectInitialize_Kinect);
  }
}

/* Model update function for TID2 */
void Qbot2_com51_update2(void)         /* Sample time: [0.1s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Qbot2_com51_M->Timing.clockTick2)) {
    ++Qbot2_com51_M->Timing.clockTickH2;
  }

  Qbot2_com51_M->Timing.t[2] = Qbot2_com51_M->Timing.clockTick2 *
    Qbot2_com51_M->Timing.stepSize2 + Qbot2_com51_M->Timing.clockTickH2 *
    Qbot2_com51_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
void Qbot2_com51_output(int_T tid)
{
  switch (tid) {
   case 0 :
    Qbot2_com51_output0();
    break;

   case 2 :
    Qbot2_com51_output2();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
void Qbot2_com51_update(int_T tid)
{
  switch (tid) {
   case 0 :
    Qbot2_com51_update0();
    break;

   case 2 :
    Qbot2_com51_update2();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void Qbot2_com51_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: Qbot2_com51/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("qbot2", "0", &Qbot2_com51_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(Qbot2_com51_DW.HILInitialize_Card,
      "enc0_dir=0;enc0_filter=1;enc0_a=0;enc0_b=0;enc0_z=1;enc0_reload=0;enc1_dir=0;enc1_filter=1;enc1_a=0;enc1_b=0;enc1_z=1;enc1_reload=0;pwm0_immediate=0;pwm1_immediate=0;pwm2_immediate=0;pwm3_immediate=0;",
      201);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(Qbot2_com51_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      return;
    }

    if ((Qbot2_com51_P.HILInitialize_set_analog_input_ && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_analog_inpu_a && is_switching)) {
      {
        int_T i1;
        const real_T *p_HILInitialize_analog_input_mini =
          Qbot2_com51_P.HILInitialize_analog_input_mini;
        real_T *dw_AIMinimums = &Qbot2_com51_DW.HILInitialize_AIMinimums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMinimums[i1] = p_HILInitialize_analog_input_mini[i1];
        }
      }

      Qbot2_com51_DW.HILInitialize_AIMinimums[8] =
        Qbot2_com51_P.HILInitialize_analog_input_mini[8];
      Qbot2_com51_DW.HILInitialize_AIMinimums[9] =
        Qbot2_com51_P.HILInitialize_analog_input_mini[8];

      {
        int_T i1;
        const real_T *p_HILInitialize_analog_input_maxi =
          Qbot2_com51_P.HILInitialize_analog_input_maxi;
        real_T *dw_AIMaximums = &Qbot2_com51_DW.HILInitialize_AIMaximums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMaximums[i1] = p_HILInitialize_analog_input_maxi[i1];
        }
      }

      Qbot2_com51_DW.HILInitialize_AIMaximums[8] =
        Qbot2_com51_P.HILInitialize_analog_input_maxi[8];
      Qbot2_com51_DW.HILInitialize_AIMaximums[9] =
        Qbot2_com51_P.HILInitialize_analog_input_maxi[8];
      result = hil_set_analog_input_ranges(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_analog_input_chan, 10U,
        &Qbot2_com51_DW.HILInitialize_AIMinimums[0],
        &Qbot2_com51_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if ((Qbot2_com51_P.HILInitialize_set_encoder_param && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_encoder_par_a && is_switching)) {
      Qbot2_com51_DW.HILInitialize_QuadratureModes[0] =
        Qbot2_com51_P.HILInitialize_quadrature;
      Qbot2_com51_DW.HILInitialize_QuadratureModes[1] =
        Qbot2_com51_P.HILInitialize_quadrature;
      Qbot2_com51_DW.HILInitialize_QuadratureModes[2] =
        Qbot2_com51_P.HILInitialize_quadrature;
      Qbot2_com51_DW.HILInitialize_QuadratureModes[3] =
        Qbot2_com51_P.HILInitialize_quadrature;
      result = hil_set_encoder_quadrature_mode(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_encoder_channels, 4U,
        (t_encoder_quadrature_mode *)
        &Qbot2_com51_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if ((Qbot2_com51_P.HILInitialize_set_encoder_count && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_encoder_cou_g && is_switching)) {
      Qbot2_com51_DW.HILInitialize_InitialEICounts[0] =
        Qbot2_com51_P.HILInitialize_initial_encoder_c;
      Qbot2_com51_DW.HILInitialize_InitialEICounts[1] =
        Qbot2_com51_P.HILInitialize_initial_encoder_c;
      Qbot2_com51_DW.HILInitialize_InitialEICounts[2] =
        Qbot2_com51_P.HILInitialize_initial_encoder_c;
      Qbot2_com51_DW.HILInitialize_InitialEICounts[3] =
        Qbot2_com51_P.HILInitialize_initial_encoder_c;
      result = hil_set_encoder_counts(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_encoder_channels, 4U,
        &Qbot2_com51_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if ((Qbot2_com51_P.HILInitialize_set_pwm_params_at && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_pwm_params__l && is_switching)) {
      uint32_T num_duty_cycle_modes = 0;
      uint32_T num_frequency_modes = 0;
      Qbot2_com51_DW.HILInitialize_POModeValues[0] =
        Qbot2_com51_P.HILInitialize_pwm_modes;
      Qbot2_com51_DW.HILInitialize_POModeValues[1] =
        Qbot2_com51_P.HILInitialize_pwm_modes;
      Qbot2_com51_DW.HILInitialize_POModeValues[2] =
        Qbot2_com51_P.HILInitialize_pwm_modes;
      Qbot2_com51_DW.HILInitialize_POModeValues[3] =
        Qbot2_com51_P.HILInitialize_pwm_modes;
      result = hil_set_pwm_mode(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_pwm_channels, 4U, (t_pwm_mode *)
        &Qbot2_com51_DW.HILInitialize_POModeValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }

      if (Qbot2_com51_DW.HILInitialize_POModeValues[0] == PWM_DUTY_CYCLE_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[0] == PWM_ONE_SHOT_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[0] == PWM_TIME_MODE) {
        Qbot2_com51_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[0];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_duty_cycle_modes++;
      } else {
        Qbot2_com51_DW.HILInitialize_POSortedChans[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[0];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_frequency_modes++;
      }

      if (Qbot2_com51_DW.HILInitialize_POModeValues[1] == PWM_DUTY_CYCLE_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[1] == PWM_ONE_SHOT_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[1] == PWM_TIME_MODE) {
        Qbot2_com51_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[1];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_duty_cycle_modes++;
      } else {
        Qbot2_com51_DW.HILInitialize_POSortedChans[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[1];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_frequency_modes++;
      }

      if (Qbot2_com51_DW.HILInitialize_POModeValues[2] == PWM_DUTY_CYCLE_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[2] == PWM_ONE_SHOT_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[2] == PWM_TIME_MODE) {
        Qbot2_com51_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[2];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_duty_cycle_modes++;
      } else {
        Qbot2_com51_DW.HILInitialize_POSortedChans[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[2];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_frequency_modes++;
      }

      if (Qbot2_com51_DW.HILInitialize_POModeValues[3] == PWM_DUTY_CYCLE_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[3] == PWM_ONE_SHOT_MODE ||
          Qbot2_com51_DW.HILInitialize_POModeValues[3] == PWM_TIME_MODE) {
        Qbot2_com51_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[3];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_duty_cycle_modes++;
      } else {
        Qbot2_com51_DW.HILInitialize_POSortedChans[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_channels[3];
        Qbot2_com51_DW.HILInitialize_POSortedFreqs[3U - num_frequency_modes] =
          Qbot2_com51_P.HILInitialize_pwm_frequency;
        num_frequency_modes++;
      }

      if (num_duty_cycle_modes > 0) {
        result = hil_set_pwm_frequency(Qbot2_com51_DW.HILInitialize_Card,
          &Qbot2_com51_DW.HILInitialize_POSortedChans[0], num_duty_cycle_modes,
          &Qbot2_com51_DW.HILInitialize_POSortedFreqs[0]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
          return;
        }
      }

      if (num_frequency_modes > 0) {
        result = hil_set_pwm_duty_cycle(Qbot2_com51_DW.HILInitialize_Card,
          &Qbot2_com51_DW.HILInitialize_POSortedChans[num_duty_cycle_modes],
          num_frequency_modes,
          &Qbot2_com51_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
          return;
        }
      }

      Qbot2_com51_DW.HILInitialize_POModeValues[0] =
        Qbot2_com51_P.HILInitialize_pwm_configuration;
      Qbot2_com51_DW.HILInitialize_POModeValues[1] =
        Qbot2_com51_P.HILInitialize_pwm_configuration;
      Qbot2_com51_DW.HILInitialize_POModeValues[2] =
        Qbot2_com51_P.HILInitialize_pwm_configuration;
      Qbot2_com51_DW.HILInitialize_POModeValues[3] =
        Qbot2_com51_P.HILInitialize_pwm_configuration;
      Qbot2_com51_DW.HILInitialize_POAlignValues[0] =
        Qbot2_com51_P.HILInitialize_pwm_alignment;
      Qbot2_com51_DW.HILInitialize_POAlignValues[1] =
        Qbot2_com51_P.HILInitialize_pwm_alignment;
      Qbot2_com51_DW.HILInitialize_POAlignValues[2] =
        Qbot2_com51_P.HILInitialize_pwm_alignment;
      Qbot2_com51_DW.HILInitialize_POAlignValues[3] =
        Qbot2_com51_P.HILInitialize_pwm_alignment;
      Qbot2_com51_DW.HILInitialize_POPolarityVals[0] =
        Qbot2_com51_P.HILInitialize_pwm_polarity;
      Qbot2_com51_DW.HILInitialize_POPolarityVals[1] =
        Qbot2_com51_P.HILInitialize_pwm_polarity;
      Qbot2_com51_DW.HILInitialize_POPolarityVals[2] =
        Qbot2_com51_P.HILInitialize_pwm_polarity;
      Qbot2_com51_DW.HILInitialize_POPolarityVals[3] =
        Qbot2_com51_P.HILInitialize_pwm_polarity;
      result = hil_set_pwm_configuration(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_pwm_channels, 4U,
        (t_pwm_configuration *) &Qbot2_com51_DW.HILInitialize_POModeValues[0],
        (t_pwm_alignment *) &Qbot2_com51_DW.HILInitialize_POAlignValues[0],
        (t_pwm_polarity *) &Qbot2_com51_DW.HILInitialize_POPolarityVals[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }

      Qbot2_com51_DW.HILInitialize_POSortedFreqs[0] =
        Qbot2_com51_P.HILInitialize_pwm_leading_deadb;
      Qbot2_com51_DW.HILInitialize_POSortedFreqs[1] =
        Qbot2_com51_P.HILInitialize_pwm_leading_deadb;
      Qbot2_com51_DW.HILInitialize_POSortedFreqs[2] =
        Qbot2_com51_P.HILInitialize_pwm_leading_deadb;
      Qbot2_com51_DW.HILInitialize_POSortedFreqs[3] =
        Qbot2_com51_P.HILInitialize_pwm_leading_deadb;
      Qbot2_com51_DW.HILInitialize_POValues[0] =
        Qbot2_com51_P.HILInitialize_pwm_trailing_dead;
      Qbot2_com51_DW.HILInitialize_POValues[1] =
        Qbot2_com51_P.HILInitialize_pwm_trailing_dead;
      Qbot2_com51_DW.HILInitialize_POValues[2] =
        Qbot2_com51_P.HILInitialize_pwm_trailing_dead;
      Qbot2_com51_DW.HILInitialize_POValues[3] =
        Qbot2_com51_P.HILInitialize_pwm_trailing_dead;
      result = hil_set_pwm_deadband(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_pwm_channels, 4U,
        &Qbot2_com51_DW.HILInitialize_POSortedFreqs[0],
        &Qbot2_com51_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if ((Qbot2_com51_P.HILInitialize_set_pwm_outputs_a && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_pwm_outputs_g && is_switching)) {
      Qbot2_com51_DW.HILInitialize_POValues[0] =
        Qbot2_com51_P.HILInitialize_initial_pwm_outpu;
      Qbot2_com51_DW.HILInitialize_POValues[1] =
        Qbot2_com51_P.HILInitialize_initial_pwm_outpu;
      Qbot2_com51_DW.HILInitialize_POValues[2] =
        Qbot2_com51_P.HILInitialize_initial_pwm_outpu;
      Qbot2_com51_DW.HILInitialize_POValues[3] =
        Qbot2_com51_P.HILInitialize_initial_pwm_outpu;
      result = hil_write_pwm(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_pwm_channels, 4U,
        &Qbot2_com51_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if (Qbot2_com51_P.HILInitialize_set_pwm_outputs_o) {
      Qbot2_com51_DW.HILInitialize_POValues[0] =
        Qbot2_com51_P.HILInitialize_watchdog_pwm_outp;
      Qbot2_com51_DW.HILInitialize_POValues[1] =
        Qbot2_com51_P.HILInitialize_watchdog_pwm_outp;
      Qbot2_com51_DW.HILInitialize_POValues[2] =
        Qbot2_com51_P.HILInitialize_watchdog_pwm_outp;
      Qbot2_com51_DW.HILInitialize_POValues[3] =
        Qbot2_com51_P.HILInitialize_watchdog_pwm_outp;
      result = hil_watchdog_set_pwm_expiration_state
        (Qbot2_com51_DW.HILInitialize_Card,
         Qbot2_com51_P.HILInitialize_pwm_channels, 4U,
         &Qbot2_com51_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }

    if ((Qbot2_com51_P.HILInitialize_set_other_outputs && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_other_outpu_m && is_switching)) {
      result = hil_write_other(Qbot2_com51_DW.HILInitialize_Card,
        Qbot2_com51_P.HILInitialize_other_output_chan, 4U,
        Qbot2_com51_P.HILInitialize_initial_other_out);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (kinect_initialize_block): '<Root>/Kinect Initialize' */

  /* S-Function Block: Qbot2_com51/Kinect Initialize (kinect_initialize_block) */
  {
    t_error result = kinect_open("0", (t_kinect_type) 1,
      &Qbot2_com51_DW.KinectInitialize_Kinect);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      return;
    }
  }

  /* Start for S-Function (stream_server_block): '<Root>/Stream Server' */

  /* S-Function Block: Qbot2_com51/Stream Server (stream_server_block) */
  {
    qthread_attr_t send_thread_attributes;
    qthread_attr_t receive_thread_attributes;
    struct qsched_param scheduling_parameters;
    int min_priority = qsched_get_priority_min(QSCHED_FIFO);
    int max_priority = qsched_get_priority_max(QSCHED_FIFO);
    t_pstream_options options;
    t_error result;
    Qbot2_com51_DW.StreamServer_Stream = NULL;
    Qbot2_com51_B.StreamServer_o4 = Qbot2_com51_P.StreamServer_default_value;
    result = 0;
    options.size = sizeof(options);
    options.flags = Qbot2_com51_P.StreamServer_Endian & PSTREAM_FLAG_ENDIAN_MASK;
    if (Qbot2_com51_P.StreamServer_Implementation ==
        STREAM_SERVER_IMPLEMENTATION_THREAD) {
      options.flags |= PSTREAM_FLAG_MULTITHREADED;
    }

    if (Qbot2_com51_P.StreamServer_Optimize == STREAM_SERVER_OPTIMIZE_LATENCY) {
      options.flags |= PSTREAM_FLAG_MINIMIZE_LATENCY;
    }

    options.send_unit_size = 8;
    options.num_send_units = 1;
    options.send_buffer_size = Qbot2_com51_P.StreamServer_SndSize;
    options.send_fifo_size = Qbot2_com51_P.StreamServer_SndFIFO;
    options.num_send_dimensions = 0;
    options.max_send_dimensions = NULL;
    if (Qbot2_com51_P.StreamServer_SndPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (Qbot2_com51_P.StreamServer_SndPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        Qbot2_com51_P.StreamServer_SndPriority;
    }

    qthread_attr_init(&send_thread_attributes);
    result = qthread_attr_setschedpolicy(&send_thread_attributes, QSCHED_FIFO);
    if (result == 0) {
      result = qthread_attr_setschedparam(&send_thread_attributes,
        &scheduling_parameters);
      if (result == 0) {
        result = qthread_attr_setinheritsched(&send_thread_attributes,
          QTHREAD_EXPLICIT_SCHED);
        if (result < 0) {
          rtmSetErrorStatus(Qbot2_com51_M,
                            "Unable to set scheduling inheritance for Stream Client sending thread");
        }
      } else {
        rtmSetErrorStatus(Qbot2_com51_M,
                          "The specified thread priority for the Stream Client sending thread is not valid for this target");
      }
    } else {
      rtmSetErrorStatus(Qbot2_com51_M,
                        "Unable to set scheduling policy for Stream Client sending thread");
    }

    options.send_thread_attributes = &send_thread_attributes;
    options.receive_unit_size = 8;
    options.num_receive_units = 1;
    options.receive_buffer_size = Qbot2_com51_P.StreamServer_RcvSize;
    options.receive_fifo_size = Qbot2_com51_P.StreamServer_RcvFIFO;
    options.num_receive_dimensions = 0;
    options.max_receive_dimensions = NULL;
    if (Qbot2_com51_P.StreamServer_RcvPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (Qbot2_com51_P.StreamServer_RcvPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        Qbot2_com51_P.StreamServer_RcvPriority;
    }

    qthread_attr_init(&receive_thread_attributes);
    if (result == 0) {
      result = qthread_attr_setschedpolicy(&receive_thread_attributes,
        QSCHED_FIFO);
      if (result == 0) {
        result = qthread_attr_setschedparam(&receive_thread_attributes,
          &scheduling_parameters);
        if (result == 0) {
          result = qthread_attr_setinheritsched(&receive_thread_attributes,
            QTHREAD_EXPLICIT_SCHED);
          if (result < 0) {
            rtmSetErrorStatus(Qbot2_com51_M,
                              "Unable to set scheduling inheritance for Stream Client receiving thread");
          }
        } else {
          rtmSetErrorStatus(Qbot2_com51_M,
                            "The specified thread priority for the Stream Client receiving thread is not valid for this target");
        }
      } else {
        rtmSetErrorStatus(Qbot2_com51_M,
                          "Unable to set scheduling policy for Stream Client receiving thread");
      }
    }

    options.receive_thread_attributes = &receive_thread_attributes;
    if (result == 0) {
      result = pstream_listen((const char *) Qbot2_com51_P.StreamServer_URI,
        &options, &Qbot2_com51_DW.StreamServer_Stream);
      if (result < 0 && result != -QERR_WOULD_BLOCK) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      }
    }

    qthread_attr_destroy(&send_thread_attributes);
    qthread_attr_destroy(&receive_thread_attributes);
  }

  /* Start for S-Function (stream_client_block): '<Root>/Stream Client' */

  /* S-Function Block: Qbot2_com51/Stream Client (stream_client_block) */
  {
    qthread_attr_t send_thread_attributes;
    qthread_attr_t receive_thread_attributes;
    struct qsched_param scheduling_parameters;
    int min_priority = qsched_get_priority_min(QSCHED_FIFO);
    int max_priority = qsched_get_priority_max(QSCHED_FIFO);
    t_pstream_options options;
    t_error result;
    Qbot2_com51_DW.StreamClient_Stream = NULL;
    Qbot2_com51_B.StreamClient_o4 = Qbot2_com51_P.StreamClient_default_value;
    result = 0;
    options.size = sizeof(options);
    options.flags = Qbot2_com51_P.StreamClient_Endian & PSTREAM_FLAG_ENDIAN_MASK;
    if (Qbot2_com51_P.StreamClient_Implementation ==
        STREAM_CLIENT_IMPLEMENTATION_THREAD) {
      options.flags |= PSTREAM_FLAG_MULTITHREADED;
    }

    if (Qbot2_com51_P.StreamClient_Optimize == STREAM_CLIENT_OPTIMIZE_LATENCY) {
      options.flags |= PSTREAM_FLAG_MINIMIZE_LATENCY;
    }

    options.send_unit_size = 8;
    options.num_send_units = 1;
    options.send_buffer_size = Qbot2_com51_P.StreamClient_SndSize;
    options.send_fifo_size = Qbot2_com51_P.StreamClient_SndFIFO;
    options.num_send_dimensions = 0;
    options.max_send_dimensions = NULL;
    if (Qbot2_com51_P.StreamClient_SndPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (Qbot2_com51_P.StreamClient_SndPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        Qbot2_com51_P.StreamClient_SndPriority;
    }

    qthread_attr_init(&send_thread_attributes);
    result = qthread_attr_setschedpolicy(&send_thread_attributes, QSCHED_FIFO);
    if (result == 0) {
      result = qthread_attr_setschedparam(&send_thread_attributes,
        &scheduling_parameters);
      if (result == 0) {
        result = qthread_attr_setinheritsched(&send_thread_attributes,
          QTHREAD_EXPLICIT_SCHED);
        if (result < 0) {
          rtmSetErrorStatus(Qbot2_com51_M,
                            "Unable to set scheduling inheritance for Stream Client sending thread");
        }
      } else {
        rtmSetErrorStatus(Qbot2_com51_M,
                          "The specified thread priority for the Stream Client sending thread is not valid for this target");
      }
    } else {
      rtmSetErrorStatus(Qbot2_com51_M,
                        "Unable to set scheduling policy for Stream Client sending thread");
    }

    options.send_thread_attributes = &send_thread_attributes;
    options.receive_unit_size = 8;
    options.num_receive_units = 1;
    options.receive_buffer_size = Qbot2_com51_P.StreamClient_RcvSize;
    options.receive_fifo_size = Qbot2_com51_P.StreamClient_RcvFIFO;
    options.num_receive_dimensions = 0;
    options.max_receive_dimensions = NULL;
    if (Qbot2_com51_P.StreamClient_RcvPriority < min_priority) {
      scheduling_parameters.sched_priority = min_priority;
    } else if (Qbot2_com51_P.StreamClient_RcvPriority > max_priority) {
      scheduling_parameters.sched_priority = max_priority;
    } else {
      scheduling_parameters.sched_priority =
        Qbot2_com51_P.StreamClient_RcvPriority;
    }

    qthread_attr_init(&receive_thread_attributes);
    if (result == 0) {
      result = qthread_attr_setschedpolicy(&receive_thread_attributes,
        QSCHED_FIFO);
      if (result == 0) {
        result = qthread_attr_setschedparam(&receive_thread_attributes,
          &scheduling_parameters);
        if (result == 0) {
          result = qthread_attr_setinheritsched(&receive_thread_attributes,
            QTHREAD_EXPLICIT_SCHED);
          if (result < 0) {
            rtmSetErrorStatus(Qbot2_com51_M,
                              "Unable to set scheduling inheritance for Stream Client receiving thread");
          }
        } else {
          rtmSetErrorStatus(Qbot2_com51_M,
                            "The specified thread priority for the Stream Client receiving thread is not valid for this target");
        }
      } else {
        rtmSetErrorStatus(Qbot2_com51_M,
                          "Unable to set scheduling policy for Stream Client receiving thread");
      }
    }

    options.receive_thread_attributes = &receive_thread_attributes;
    if (result == 0) {
      result = pstream_connect((const char *) Qbot2_com51_P.StreamClient_URI,
        &options, &Qbot2_com51_DW.StreamClient_Stream);
      if (result < 0 && result != -QERR_WOULD_BLOCK) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
      }
    }

    qthread_attr_destroy(&send_thread_attributes);
    qthread_attr_destroy(&receive_thread_attributes);
  }

  /* InitializeConditions for S-Function (kinect_initialize_block): '<Root>/Kinect Initialize' */

  /* S-Function Block: Qbot2_com51/Kinect Initialize (kinect_initialize_block) */
  {
    if (rtmIsFirstInitCond(Qbot2_com51_M)) {
      t_error result = kinect_initialize(Qbot2_com51_DW.KinectInitialize_Kinect);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        return;
      }
    }
  }

  /* set "at time zero" to false */
  if (rtmIsFirstInitCond(Qbot2_com51_M)) {
    rtmSetFirstInitCond(Qbot2_com51_M, 0);
  }
}

/* Model terminate function */
void Qbot2_com51_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: Qbot2_com51/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_pwm_outputs = 0;
    t_uint32 num_final_other_outputs = 0;
    hil_task_stop_all(Qbot2_com51_DW.HILInitialize_Card);
    hil_monitor_stop_all(Qbot2_com51_DW.HILInitialize_Card);
    is_switching = false;
    if ((Qbot2_com51_P.HILInitialize_set_pwm_outputs_c && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_pwm_outputs_l && is_switching)) {
      Qbot2_com51_DW.HILInitialize_POValues[0] =
        Qbot2_com51_P.HILInitialize_final_pwm_outputs;
      Qbot2_com51_DW.HILInitialize_POValues[1] =
        Qbot2_com51_P.HILInitialize_final_pwm_outputs;
      Qbot2_com51_DW.HILInitialize_POValues[2] =
        Qbot2_com51_P.HILInitialize_final_pwm_outputs;
      Qbot2_com51_DW.HILInitialize_POValues[3] =
        Qbot2_com51_P.HILInitialize_final_pwm_outputs;
      num_final_pwm_outputs = 4U;
    }

    if ((Qbot2_com51_P.HILInitialize_set_other_outpu_b && !is_switching) ||
        (Qbot2_com51_P.HILInitialize_set_other_outpu_e && is_switching)) {
      num_final_other_outputs = 4U;
    }

    if (0
        || num_final_pwm_outputs > 0
        || num_final_other_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(Qbot2_com51_DW.HILInitialize_Card
                         , NULL, 0
                         , Qbot2_com51_P.HILInitialize_pwm_channels,
                         num_final_pwm_outputs
                         , NULL, 0
                         , Qbot2_com51_P.HILInitialize_other_output_chan,
                         num_final_other_outputs
                         , NULL
                         , &Qbot2_com51_DW.HILInitialize_POValues[0]
                         , (t_boolean *) NULL
                         , Qbot2_com51_P.HILInitialize_final_other_outpu
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_pwm_outputs > 0) {
          local_result = hil_write_pwm(Qbot2_com51_DW.HILInitialize_Card,
            Qbot2_com51_P.HILInitialize_pwm_channels, num_final_pwm_outputs,
            &Qbot2_com51_DW.HILInitialize_POValues[0]);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_other_outputs > 0) {
          local_result = hil_write_other(Qbot2_com51_DW.HILInitialize_Card,
            Qbot2_com51_P.HILInitialize_other_output_chan,
            num_final_other_outputs,
            Qbot2_com51_P.HILInitialize_final_other_outpu);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(Qbot2_com51_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(Qbot2_com51_DW.HILInitialize_Card);
    hil_monitor_delete_all(Qbot2_com51_DW.HILInitialize_Card);
    hil_close(Qbot2_com51_DW.HILInitialize_Card);
    Qbot2_com51_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for S-Function (kinect_initialize_block): '<Root>/Kinect Initialize' */

  /* S-Function Block: Qbot2_com51/Kinect Initialize (kinect_initialize_block) */
  {
    kinect_close(Qbot2_com51_DW.KinectInitialize_Kinect);
  }

  /* Terminate for S-Function (stream_server_block): '<Root>/Stream Server' */

  /* S-Function Block: Qbot2_com51/Stream Server (stream_server_block) */
  {
    if (Qbot2_com51_DW.StreamServer_Stream != NULL) {
      pstream_close(Qbot2_com51_DW.StreamServer_Stream);
    }

    Qbot2_com51_DW.StreamServer_Stream = NULL;
  }

  /* Terminate for S-Function (stream_client_block): '<Root>/Stream Client' */

  /* S-Function Block: Qbot2_com51/Stream Client (stream_client_block) */
  {
    if (Qbot2_com51_DW.StreamClient_Stream != NULL) {
      pstream_close(Qbot2_com51_DW.StreamClient_Stream);
    }

    Qbot2_com51_DW.StreamClient_Stream = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  Qbot2_com51_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  Qbot2_com51_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Qbot2_com51_initialize();
}

void MdlTerminate(void)
{
  Qbot2_com51_terminate();
}

/* Registration function */
RT_MODEL_Qbot2_com51_T *Qbot2_com51(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Qbot2_com51_M, 0,
                sizeof(RT_MODEL_Qbot2_com51_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Qbot2_com51_M->solverInfo,
                          &Qbot2_com51_M->Timing.simTimeStep);
    rtsiSetTPtr(&Qbot2_com51_M->solverInfo, &rtmGetTPtr(Qbot2_com51_M));
    rtsiSetStepSizePtr(&Qbot2_com51_M->solverInfo,
                       &Qbot2_com51_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&Qbot2_com51_M->solverInfo, (&rtmGetErrorStatus
      (Qbot2_com51_M)));
    rtsiSetRTModelPtr(&Qbot2_com51_M->solverInfo, Qbot2_com51_M);
  }

  rtsiSetSimTimeStep(&Qbot2_com51_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&Qbot2_com51_M->solverInfo,"FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Qbot2_com51_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    Qbot2_com51_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Qbot2_com51_M->Timing.sampleTimes = (&Qbot2_com51_M->
      Timing.sampleTimesArray[0]);
    Qbot2_com51_M->Timing.offsetTimes = (&Qbot2_com51_M->
      Timing.offsetTimesArray[0]);

    /* task periods */
    Qbot2_com51_M->Timing.sampleTimes[0] = (0.0);
    Qbot2_com51_M->Timing.sampleTimes[1] = (0.01);
    Qbot2_com51_M->Timing.sampleTimes[2] = (0.1);

    /* task offsets */
    Qbot2_com51_M->Timing.offsetTimes[0] = (0.0);
    Qbot2_com51_M->Timing.offsetTimes[1] = (0.0);
    Qbot2_com51_M->Timing.offsetTimes[2] = (0.0);
  }

  rtmSetTPtr(Qbot2_com51_M, &Qbot2_com51_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Qbot2_com51_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits = Qbot2_com51_M->Timing.perTaskSampleHitsArray;
    Qbot2_com51_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    Qbot2_com51_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Qbot2_com51_M, -1);
  Qbot2_com51_M->Timing.stepSize0 = 0.01;
  Qbot2_com51_M->Timing.stepSize1 = 0.01;
  Qbot2_com51_M->Timing.stepSize2 = 0.1;
  rtmSetFirstInitCond(Qbot2_com51_M, 1);

  /* External mode info */
  Qbot2_com51_M->Sizes.checksums[0] = (910434832U);
  Qbot2_com51_M->Sizes.checksums[1] = (27834169U);
  Qbot2_com51_M->Sizes.checksums[2] = (1967867708U);
  Qbot2_com51_M->Sizes.checksums[3] = (2583443149U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    Qbot2_com51_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Qbot2_com51_M->extModeInfo,
      &Qbot2_com51_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Qbot2_com51_M->extModeInfo,
                        Qbot2_com51_M->Sizes.checksums);
    rteiSetTPtr(Qbot2_com51_M->extModeInfo, rtmGetTPtr(Qbot2_com51_M));
  }

  Qbot2_com51_M->solverInfoPtr = (&Qbot2_com51_M->solverInfo);
  Qbot2_com51_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&Qbot2_com51_M->solverInfo, 0.01);
  rtsiSetSolverMode(&Qbot2_com51_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  Qbot2_com51_M->ModelData.blockIO = ((void *) &Qbot2_com51_B);
  (void) memset(((void *) &Qbot2_com51_B), 0,
                sizeof(B_Qbot2_com51_T));

  /* parameters */
  Qbot2_com51_M->ModelData.defaultParam = ((real_T *)&Qbot2_com51_P);

  /* states (dwork) */
  Qbot2_com51_M->ModelData.dwork = ((void *) &Qbot2_com51_DW);
  (void) memset((void *)&Qbot2_com51_DW, 0,
                sizeof(DW_Qbot2_com51_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    Qbot2_com51_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 18;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  Qbot2_com51_M->Sizes.numContStates = (0);/* Number of continuous states */
  Qbot2_com51_M->Sizes.numY = (0);     /* Number of model outputs */
  Qbot2_com51_M->Sizes.numU = (0);     /* Number of model inputs */
  Qbot2_com51_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Qbot2_com51_M->Sizes.numSampTimes = (3);/* Number of sample times */
  Qbot2_com51_M->Sizes.numBlocks = (21);/* Number of blocks */
  Qbot2_com51_M->Sizes.numBlockIO = (13);/* Number of block outputs */
  Qbot2_com51_M->Sizes.numBlockPrms = (184);/* Sum of parameter "widths" */
  return Qbot2_com51_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
