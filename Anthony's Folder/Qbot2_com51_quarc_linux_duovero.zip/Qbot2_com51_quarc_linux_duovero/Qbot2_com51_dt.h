/*
 * Qbot2_com51_dt.h
 *
 * Code generation for model "Qbot2_com51".
 *
 * Model version              : 1.801
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Tue Oct 20 10:46:05 2015
 *
 * Target selection: quarc_linux_duovero.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(t_timeout),
  sizeof(t_kinect),
  sizeof(t_pstream),
  sizeof(t_card)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "t_timeout",
  "t_kinect",
  "t_pstream",
  "t_card"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&Qbot2_com51_B.ComputationTime), 0, 0, 4 },

  { (char_T *)(&Qbot2_com51_B.KinectInitialize), 6, 0, 3 },

  { (char_T *)(&Qbot2_com51_B.StreamServer_o1), 3, 0, 2 },

  { (char_T *)(&Qbot2_com51_B.StreamServer_o3), 8, 0, 4 }
  ,

  { (char_T *)(&Qbot2_com51_DW.ComputationTime_BeginTime), 14, 0, 2 },

  { (char_T *)(&Qbot2_com51_DW.HILInitialize_AIMinimums[0]), 0, 0, 36 },

  { (char_T *)(&Qbot2_com51_DW.KinectInitialize_Kinect), 15, 0, 1 },

  { (char_T *)(&Qbot2_com51_DW.StreamServer_Stream), 16, 0, 2 },

  { (char_T *)(&Qbot2_com51_DW.HILInitialize_Card), 17, 0, 1 },

  { (char_T *)(&Qbot2_com51_DW.HILInitialize_QuadratureModes[0]), 6, 0, 20 },

  { (char_T *)(&Qbot2_com51_DW.HILInitialize_POSortedChans[0]), 7, 0, 4 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  11U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&Qbot2_com51_P.HILInitialize_analog_input_maxi[0]), 0, 0, 38 },

  { (char_T *)(&Qbot2_com51_P.HILInitialize_initial_encoder_c), 6, 0, 6 },

  { (char_T *)(&Qbot2_com51_P.HILInitialize_analog_input_chan[0]), 7, 0, 23 },

  { (char_T *)(&Qbot2_com51_P.HILInitialize_active), 8, 0, 36 },

  { (char_T *)(&Qbot2_com51_P.SineWave_Amp), 0, 0, 7 },

  { (char_T *)(&Qbot2_com51_P.StreamServer_SndPriority), 6, 0, 4 },

  { (char_T *)(&Qbot2_com51_P.StreamServer_SndSize), 7, 0, 8 },

  { (char_T *)(&Qbot2_com51_P.StreamServer_Optimize), 2, 0, 4 },

  { (char_T *)(&Qbot2_com51_P.StreamServer_URI[0]), 3, 0, 56 },

  { (char_T *)(&Qbot2_com51_P.StreamServer_Active), 8, 0, 2 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  10U,
  rtPTransitions
};

/* [EOF] Qbot2_com51_dt.h */
