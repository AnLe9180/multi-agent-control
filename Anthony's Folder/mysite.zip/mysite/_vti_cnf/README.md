vti_encoding:SR|utf8-nl
vti_author:SR|DESKTOP-NO6QIGQ\\Le
vti_modifiedby:SR|DESKTOP-NO6QIGQ\\Le
vti_timelastmodified:TR|30 Apr 2017 23:24:27 -0000
vti_timecreated:TR|30 Apr 2017 23:24:27 -0000
vti_cacheddtm:TX|30 Apr 2017 23:24:27 -0000
vti_filesize:IR|1511
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
