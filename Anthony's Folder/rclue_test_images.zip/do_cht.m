function [Accumulator, img_accum, img_edges, strongest_point] = do_cht(edges)
    



Imbinary = edges;
r = 14;
thresh = 18;

if thresh < 4
    error('HOUGHCIRCLE:: Treshold value must be bigger or equal to 4');
end

%Voting
Accumulator = zeros(size(Imbinary)); % initialize the accumulator
[yIndex, xIndex] = find(Imbinary); % find x,y of edge pixels
numRow = size(Imbinary,1); % number of rows in the binary image
numCol = size(Imbinary,2); % number of columns in the binary image
r2 = r^2; % square of radius, to prevent its calculation in the loop

for cnt = 1:numel(xIndex)
    low=xIndex(cnt)-r;
    high=xIndex(cnt)+r;
   
    if (low<1)
        low=1;
    end
   
    if (high>numCol)
        high=numCol;
    end
   
    for x0 = low:high
        yOffset = sqrt(r2-(xIndex(cnt)-x0)^2);
        y01 = round(yIndex(cnt)-yOffset);
        y02 = round(yIndex(cnt)+yOffset);
               
        if y01 < numRow && y01 >= 1
            Accumulator(y01,x0) = Accumulator(y01,x0)+1;
        end
       
        if y02 < numRow && y02 >= 1
            Accumulator(y02,x0) = Accumulator(y02,x0)+1;
        end
    end
end

% Finding local maxima in Accumulator
y0detect = []; x0detect = [];
AccumulatorbinaryMax = imregionalmax(Accumulator);
[Potential_y0, Potential_x0] = find(AccumulatorbinaryMax == 1);
Accumulatortemp = Accumulator - thresh;
for cnt = 1:numel(Potential_y0)
    if Accumulatortemp(Potential_y0(cnt),Potential_x0(cnt)) >= 0
        y0detect = [y0detect;Potential_y0(cnt)];
        x0detect = [x0detect;Potential_x0(cnt)];
    end
end



img_edges = conv_rgb(edges);
img_accum = conv_rgb(Accumulator);

[col_maxima, row_indices] = max(Accumulator);
[maximum, col_index] = max(col_maxima);
strongest_point = [row_indices(col_index) col_index maximum];

img_accum = img_accum ./ maximum;
end

function M = conv_rgb(i)
i_size = size(i);
M = single(zeros(i_size(1),i_size(2),3));
M(:,:,1) = i;
M(:,:,2) = i;
M(:,:,3) = i;

end
