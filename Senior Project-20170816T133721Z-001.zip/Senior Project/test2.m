rho_star=.5;
omega_star=.5;
kp = .5;
U = [0 0];
Px=2
Py=3
Pxt=0
Pyt=0
[phi, rho] = cart2pol((Px-Pxt),(Py-Pyt));

%J_i=[x(i)/(sqrt(x(i)^2+y(i)^2)) y(i)/(sqrt(x(i)^2+y(i)^2)); -y(i)/(x(i)^2+y(i)^2) x(i)/(x(i)^2+y(i)^2)];
J_i=[ (Px-Pxt)/phi, (Py-Pyt)/phi;    -(Py-Pyt)/(1+((Py-Pyt)/(Px-Pxt))^2),  1/(1+((Py-Pyt)/(Px-Pxt))^2) ];
inv(J_i)
U = inv(J_i)*[kp*(rho_star-rho); omega_star];


%%%
function [Ux,Uy] = Basid_Pdot(Vc, theta,Wc)
%#codegen
theta=theta(3)

l=.0235; %#length between the two wheels in meters

Px_dot = Vc*cos(theta)-l*sin(theta)*Wc;

Py_dot = Vc*sin(theta)+l*cos(theta)*Wc;

Ux = Px_dot;
Uy = Py_dot;
