time = Vc.time(:,1);
V = Vc_follow.signals.values(:,1);
W = Wc_follow.signals.values(:,1);


plot(x(:,1),y(:,1))